package com.example.livraison_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LivraisonBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
